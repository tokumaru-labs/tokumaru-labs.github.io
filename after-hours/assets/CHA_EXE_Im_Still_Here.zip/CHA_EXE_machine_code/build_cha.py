#!/usr/bin/env python3
"""CHA.EXE: a Windows x64 PE made from hand-written machine-code bytes.

No compiler, no assembler, no third-party packages. Python only lays out the PE
container and patches documented RVA/displacement/relocation fields. The CPU
instructions are the literal hexadecimal bytes below.
"""

from __future__ import annotations

import hashlib
import struct
from pathlib import Path

FILE_ALIGN = 0x200
SECT_ALIGN = 0x1000
IMAGE_BASE = 0x140000000
HEADER_SIZE = 0x400
TEXT_RVA, RDATA_RVA, IDATA_RVA, RELOC_RVA = 0x1000, 0x2000, 0x3000, 0x4000

TITLE = "CHA.EXE"
MESSAGE = "I'M STILL HERE."


def align(value: int, multiple: int) -> int:
    return (value + multiple - 1) // multiple * multiple


def u16(value: int) -> bytes:
    return struct.pack("<H", value)


def u32(value: int) -> bytes:
    return struct.pack("<I", value)


def u64(value: int) -> bytes:
    return struct.pack("<Q", value)


def append_aligned(data: bytearray, boundary: int) -> None:
    data.extend(bytes(align(len(data), boundary) - len(data)))


def utf16z(text: str) -> bytes:
    return text.encode("utf-16-le") + b"\0\0"


# The complete set of CPU instructions: authored by hand as hexadecimal bytes.
# The zero bytes are placeholders for one absolute VA and three RIP displacements.
# Windows x64 ABI: RCX=owner, RDX=text, R8=caption, R9D=MB_ICONINFORMATION.
# RSP is 16-byte aligned at the call site, with 32 bytes of shadow space.
INSTRUCTIONS = [
    ("sub rsp, 28h",                 "48 83 EC 28"),
    ("xor ecx, ecx",                "31 C9"),
    ("mov rdx, imm64 (text VA)",    "48 BA 00 00 00 00 00 00 00 00"),
    ("lea r8, [rip + caption]",     "4C 8D 05 00 00 00 00"),
    ("mov r9d, 40h",                "41 B9 40 00 00 00"),
    ("call [rip + MessageBoxW IAT]", "FF 15 00 00 00 00"),
    ("xor ecx, ecx",                "31 C9"),
    ("call [rip + ExitProcess IAT]", "FF 15 00 00 00 00"),
    ("xor eax, eax",                "31 C0"),
    ("add rsp, 28h",                "48 83 C4 28"),
    ("ret",                         "C3"),
]


def build() -> tuple[bytes, dict[str, int]]:
    # ------- .rdata: read-only Unicode strings -------
    rdata = bytearray(utf16z(MESSAGE))
    caption_offset = len(rdata)
    rdata += utf16z(TITLE)
    text_va = IMAGE_BASE + RDATA_RVA
    caption_rva = RDATA_RVA + caption_offset

    # ------- .idata: standard, name-based Win32 imports -------
    imports = bytearray(3 * 20)  # two IMAGE_IMPORT_DESCRIPTOR + terminating zero
    append_aligned(imports, 8)

    def reserve_thunks() -> int:
        offset = len(imports)
        imports.extend(bytes(16))  # one IMAGE_THUNK_DATA64 + terminating null
        return offset

    ilt_kernel = reserve_thunks()
    ilt_user = reserve_thunks()
    iat_kernel = reserve_thunks()
    iat_user = reserve_thunks()

    def import_by_name(name: str) -> int:
        append_aligned(imports, 2)
        offset = len(imports)
        imports.extend(u16(0))  # hint = 0; loader searches by name
        imports.extend(name.encode("ascii") + b"\0")
        return IDATA_RVA + offset

    exit_hn_rva = import_by_name("ExitProcess")
    box_hn_rva = import_by_name("MessageBoxW")
    name_kernel_offset = len(imports)
    imports += b"KERNEL32.dll\0"
    name_user_offset = len(imports)
    imports += b"USER32.dll\0"

    for off in (ilt_kernel, iat_kernel):
        struct.pack_into("<Q", imports, off, exit_hn_rva)
    for off in (ilt_user, iat_user):
        struct.pack_into("<Q", imports, off, box_hn_rva)

    # IMAGE_IMPORT_DESCRIPTOR: ILT RVA, timestamp, forwarder chain, name, IAT RVA
    struct.pack_into("<IIIII", imports, 0,
                     IDATA_RVA + ilt_kernel, 0, 0,
                     IDATA_RVA + name_kernel_offset, IDATA_RVA + iat_kernel)
    struct.pack_into("<IIIII", imports, 20,
                     IDATA_RVA + ilt_user, 0, 0,
                     IDATA_RVA + name_user_offset, IDATA_RVA + iat_user)
    assert len(imports) <= FILE_ALIGN

    # ------- .text: literal x64 opcodes; patch encoded operands -------
    text = bytearray()
    positions = {}
    for instruction, machine_hex in INSTRUCTIONS:
        positions[instruction] = len(text)
        text.extend(bytes.fromhex(machine_hex))

    absolute_va_offset = positions["mov rdx, imm64 (text VA)"] + 2
    struct.pack_into("<Q", text, absolute_va_offset, text_va)

    def patch_rip(instruction: str, disp_field_offset: int, target_rva: int) -> None:
        field = positions[instruction] + disp_field_offset
        next_rva = TEXT_RVA + field + 4
        struct.pack_into("<i", text, field, target_rva - next_rva)

    patch_rip("lea r8, [rip + caption]", 3, caption_rva)
    patch_rip("call [rip + MessageBoxW IAT]", 2, IDATA_RVA + iat_user)
    patch_rip("call [rip + ExitProcess IAT]", 2, IDATA_RVA + iat_kernel)
    assert len(text) == 50

    # ------- .reloc: one IMAGE_REL_BASED_DIR64 relocation (type 10) -------
    # The 'mov rdx, imm64' immediate is a full virtual address; the Windows
    # loader adjusts it when ASLR chooses another image base.
    relocation_offset = absolute_va_offset  # within 4KiB .text page
    assert relocation_offset == 8
    reloc = bytearray()
    reloc += u32(TEXT_RVA)  # page RVA
    reloc += u32(12)  # block size, including one entry and a padding entry
    reloc += u16(0xA000 | relocation_offset)  # DIR64, page offset 8
    reloc += u16(0)  # ABSOLUTE pad entry

    # ------- PE/COFF container (NOT generated by compiler / assembler) -------
    sections = [
        (b".text", TEXT_RVA, text, 0x60000020),  # code, readable, executable
        (b".rdata", RDATA_RVA, rdata, 0x40000040),  # initialized, readable
        (b".idata", IDATA_RVA, imports, 0xC0000040),  # writable IAT
        (b".reloc", RELOC_RVA, reloc, 0x42000040),  # discardable, readable
    ]
    assert all(len(data) <= FILE_ALIGN for _, _, data, _ in sections)

    dos = bytearray(0x80)
    dos[:2] = b"MZ"
    struct.pack_into("<I", dos, 0x3C, 0x80)

    # PE signature and 20-byte COFF file header
    coff = struct.pack("<HHIIIHH", 0x8664, 4, 0, 0, 0, 0xF0, 0x0022)
    opt = bytearray(0xF0)
    struct.pack_into("<H", opt, 0, 0x20B)  # PE32+ x64
    struct.pack_into("<I", opt, 4, FILE_ALIGN)  # SizeOfCode
    struct.pack_into("<I", opt, 8, 3 * FILE_ALIGN)  # SizeOfInitializedData
    struct.pack_into("<I", opt, 16, TEXT_RVA)  # AddressOfEntryPoint
    struct.pack_into("<I", opt, 20, TEXT_RVA)  # BaseOfCode
    struct.pack_into("<Q", opt, 24, IMAGE_BASE)
    struct.pack_into("<I", opt, 32, SECT_ALIGN)
    struct.pack_into("<I", opt, 36, FILE_ALIGN)
    struct.pack_into("<H", opt, 40, 6)  # MajorOperatingSystemVersion
    struct.pack_into("<H", opt, 48, 6)  # MajorSubsystemVersion
    struct.pack_into("<I", opt, 56, 0x5000)  # SizeOfImage
    struct.pack_into("<I", opt, 60, HEADER_SIZE)
    struct.pack_into("<H", opt, 68, 2)  # IMAGE_SUBSYSTEM_WINDOWS_GUI
    struct.pack_into("<H", opt, 70, 0x8160)  # ASLR + HighEntropyVA + NX + TS aware
    struct.pack_into("<Q", opt, 72, 0x100000)  # SizeOfStackReserve
    struct.pack_into("<Q", opt, 80, 0x1000)  # SizeOfStackCommit
    struct.pack_into("<Q", opt, 88, 0x100000)  # SizeOfHeapReserve
    struct.pack_into("<Q", opt, 96, 0x1000)  # SizeOfHeapCommit
    struct.pack_into("<I", opt, 108, 16)  # NumberOfRvaAndSizes

    def data_directory(index: int, rva: int, size: int) -> None:
        struct.pack_into("<II", opt, 112 + index * 8, rva, size)

    data_directory(1, IDATA_RVA, 3 * 20)  # IMPORT
    data_directory(5, RELOC_RVA, len(reloc))  # BASERELOC
    data_directory(12, IDATA_RVA + iat_kernel, 32)  # IAT, contiguous two arrays

    pe = bytearray(dos + b"PE\0\0" + coff + opt)
    for idx, (name, rva, data, characteristics) in enumerate(sections):
        assert len(name) <= 8
        raw_offset = HEADER_SIZE + idx * FILE_ALIGN
        sh = struct.pack("<8sIIIIIIHHI", name.ljust(8, b"\0"), len(data),
                         rva, FILE_ALIGN, raw_offset, 0, 0, 0, 0, characteristics)
        pe.extend(sh)
    assert len(pe) <= HEADER_SIZE
    pe.extend(bytes(HEADER_SIZE - len(pe)))
    for name, rva, data, char in sections:
        pe.extend(data)
        pe.extend(bytes(FILE_ALIGN - len(data)))

    return bytes(pe), {
        "entry_rva": TEXT_RVA,
        "relocation_rva": RELOC_RVA,
        "relocation_target_rva": TEXT_RVA + absolute_va_offset,
        "message_rva": RDATA_RVA,
        "caption_rva": caption_rva,
        "exitprocess_iat_rva": IDATA_RVA + iat_kernel,
        "messagebox_iat_rva": IDATA_RVA + iat_user,
        "size": len(pe),
    }


def main() -> None:
    program, meta = build()
    output = Path(__file__).with_name("CHA.exe")
    output.write_bytes(program)
    sha = hashlib.sha256(program).hexdigest()
    print(f"Wrote {output.name} ({len(program)} bytes)")
    print(f"SHA-256: {sha}")
    for key, value in meta.items():
        print(f"{key}: 0x{value:X}")


if __name__ == "__main__":
    main()
