#!/usr/bin/env python3
"""Standalone-format and reproducibility checks for the handwritten CHA.EXE."""

import hashlib
import struct
from pathlib import Path

import build_cha

p = Path(__file__).with_name("CHA.exe")
raw = p.read_bytes()
assert build_cha.MESSAGE == "I'M STILL HERE."
assert build_cha.TITLE == "CHA.EXE"
expected, meta = build_cha.build()
assert raw == expected, "CHA.exe differs from the reproducible machine-code builder"

unpack16 = lambda off: struct.unpack_from("<H", raw, off)[0]
unpack32 = lambda off: struct.unpack_from("<I", raw, off)[0]
unpack64 = lambda off: struct.unpack_from("<Q", raw, off)[0]

assert raw[:2] == b"MZ"
pe = unpack32(0x3c)
assert raw[pe:pe + 4] == b"PE\0\0"
assert unpack16(pe + 4) == 0x8664  # AMD64
assert unpack16(pe + 6) == 4  # .text .rdata .idata .reloc
opt = pe + 4 + 20
assert unpack16(opt) == 0x20B  # PE32+
assert unpack16(opt + 68) == 2  # WINDOWS_GUI
assert unpack16(opt + 70) & 0x0160 == 0x0160  # ASLR/NX
assert unpack32(opt + 16) == 0x1000  # Entry point
assert unpack32(opt + 112 + 1 * 8) == 0x3000  # Import directory
assert unpack32(opt + 112 + 5 * 8) == 0x4000  # Relocations

sections = {}
section_table = opt + unpack16(pe + 4 + 16)
for i in range(4):
    sh = section_table + i * 40
    name = raw[sh:sh + 8].split(b"\0")[0].decode("ascii")
    virt_size, rva, file_size, file_offset = struct.unpack_from("<IIII", raw, sh + 8)
    sections[name] = (rva, file_offset, virt_size, file_size)
assert tuple(sections) == (".text", ".rdata", ".idata", ".reloc")


def at_rva(rva):
    for base, file_offset, virt_size, file_size in sections.values():
        if base <= rva < base + virt_size:
            return file_offset + rva - base
    raise AssertionError(f"Unmapped RVA: {rva:#x}")


assert raw[at_rva(0x1000):at_rva(0x1000) + 4] == bytes.fromhex("48 83 EC 28")
assert unpack64(at_rva(0x1008)) == 0x140002000
assert raw[at_rva(meta["message_rva"]):at_rva(meta["message_rva"]) + len(build_cha.utf16z(build_cha.MESSAGE))] == build_cha.utf16z(build_cha.MESSAGE)
assert raw[at_rva(meta["caption_rva"]):at_rva(meta["caption_rva"]) + len(build_cha.utf16z(build_cha.TITLE))] == build_cha.utf16z(build_cha.TITLE)
assert raw[at_rva(0x1008):at_rva(0x1008) + 8] == struct.pack('<Q', 0x140002000)
assert unpack32(at_rva(0x4000)) == 0x1000
assert unpack32(at_rva(0x4000) + 4) == 12
assert unpack16(at_rva(0x4000) + 8) == 0xA008

for idx, dll, function in ((0, b"KERNEL32.dll\0", b"ExitProcess\0"),
                           (1, b"USER32.dll\0", b"MessageBoxW\0")):
    rva = 0x3000 + idx * 20
    ilt_rva, timestamp, forwarder, name_rva, iat_rva = struct.unpack_from('<IIIII', raw, at_rva(rva))
    assert raw[at_rva(name_rva):at_rva(name_rva) + len(dll)] == dll
    hint_name_rva = unpack64(at_rva(ilt_rva))
    assert raw[at_rva(hint_name_rva) + 2:at_rva(hint_name_rva) + 2 + len(function)] == function
    assert unpack64(at_rva(iat_rva)) == hint_name_rva

print("PASS: PE32+ x64 GUI container, sections, ASLR/NX, entry point, imports,")
print("      Unicode messages, relocations, and byte-for-byte reproducibility.")
print(f"SHA-256: {hashlib.sha256(raw).hexdigest()}")
